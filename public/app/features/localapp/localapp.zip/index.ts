import coreModule from 'app/core/core_module';

import { LocalAppCtrl } from './LocalAppCtrl';

coreModule.controller('LocalAppCtrl', LocalAppCtrl);
